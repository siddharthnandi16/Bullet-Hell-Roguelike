#include "content/patterns.h"
